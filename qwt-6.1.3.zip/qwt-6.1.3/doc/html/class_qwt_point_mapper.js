var class_qwt_point_mapper =
[
    [ "TransformationFlags", "class_qwt_point_mapper.html#af7a8c38f6dd7faf8396a87a882e2f967", null ],
    [ "TransformationFlag", "class_qwt_point_mapper.html#aafc07ceadb3f311057037ca8680e1c23", [
      [ "RoundPoints", "class_qwt_point_mapper.html#aafc07ceadb3f311057037ca8680e1c23a0e367a1519b0005cad8bb324854cc8e3", null ],
      [ "WeedOutPoints", "class_qwt_point_mapper.html#aafc07ceadb3f311057037ca8680e1c23a288f41a8e4d53c895f7bffaaa9b5d9e4", null ]
    ] ],
    [ "QwtPointMapper", "class_qwt_point_mapper.html#a6e5eabb9c1af9b035023376fa2e1c472", null ],
    [ "~QwtPointMapper", "class_qwt_point_mapper.html#aabe6a70dae5784e8b67f4527c51e0c09", null ],
    [ "boundingRect", "class_qwt_point_mapper.html#a1dd7644e312d7d05ae238759470180d4", null ],
    [ "flags", "class_qwt_point_mapper.html#aeb3ce1915222fab8a6e2ab83acd90f93", null ],
    [ "setBoundingRect", "class_qwt_point_mapper.html#a03910571df91575456e98134f6543650", null ],
    [ "setFlag", "class_qwt_point_mapper.html#a6e03e14718d3d66a0f6a02fec7fcaeed", null ],
    [ "setFlags", "class_qwt_point_mapper.html#ab556bd339cca487f25e2d894c51abe85", null ],
    [ "testFlag", "class_qwt_point_mapper.html#acadf83f0fdb3123813b5c1eac20c3ad5", null ],
    [ "toImage", "class_qwt_point_mapper.html#a68b7b12f5e5cdad135d2d4aa408b1bdd", null ],
    [ "toPoints", "class_qwt_point_mapper.html#a136350d94f21f7b7c309d3f207d283b7", null ],
    [ "toPointsF", "class_qwt_point_mapper.html#ae096ea4844f89bfaebb4806572d935a8", null ],
    [ "toPolygon", "class_qwt_point_mapper.html#a6712085a3930dd5d5cebe3fa9eabb522", null ],
    [ "toPolygonF", "class_qwt_point_mapper.html#a63b8ce75856b3be11532fdf4bd9602a2", null ]
];