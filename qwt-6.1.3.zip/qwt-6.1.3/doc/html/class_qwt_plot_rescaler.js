var class_qwt_plot_rescaler =
[
    [ "ExpandingDirection", "class_qwt_plot_rescaler.html#a1c314e9513cef076a79381111aa67585", [
      [ "ExpandUp", "class_qwt_plot_rescaler.html#a1c314e9513cef076a79381111aa67585a10adc202ca84a06179b905db6802668c", null ],
      [ "ExpandDown", "class_qwt_plot_rescaler.html#a1c314e9513cef076a79381111aa67585a856d9a1fe75ed6398a1b3c4b60f3fbfd", null ],
      [ "ExpandBoth", "class_qwt_plot_rescaler.html#a1c314e9513cef076a79381111aa67585a3dfb8208dfb62200761e4221763db033", null ]
    ] ],
    [ "RescalePolicy", "class_qwt_plot_rescaler.html#a6a614b832876a7641cb5410ba81d9d6a", [
      [ "Fixed", "class_qwt_plot_rescaler.html#a6a614b832876a7641cb5410ba81d9d6aab8f9ce10c092bee12de74b05a46b6e9c", null ],
      [ "Expanding", "class_qwt_plot_rescaler.html#a6a614b832876a7641cb5410ba81d9d6aac0b9db1ea3c5666792c2a9813ca5d7e1", null ],
      [ "Fitting", "class_qwt_plot_rescaler.html#a6a614b832876a7641cb5410ba81d9d6aa30a43b11d9df23f66110b65d1e249db1", null ]
    ] ],
    [ "QwtPlotRescaler", "class_qwt_plot_rescaler.html#a4bef342d0a571af31685c2ff88def5d5", null ],
    [ "~QwtPlotRescaler", "class_qwt_plot_rescaler.html#ae34a0dbae9074c211f36c765142d8ddd", null ],
    [ "aspectRatio", "class_qwt_plot_rescaler.html#a896b940761b437516043695d2687dd1c", null ],
    [ "canvas", "class_qwt_plot_rescaler.html#ad4aa9bf81032b822b848774ee21142ce", null ],
    [ "canvas", "class_qwt_plot_rescaler.html#ae324f6b86350254e1623853bf9ad9f77", null ],
    [ "canvasResizeEvent", "class_qwt_plot_rescaler.html#a5490a4a1b576b1118c095cc54810e2aa", null ],
    [ "eventFilter", "class_qwt_plot_rescaler.html#a2a6809f3940b9114a1faed30f6edc3d0", null ],
    [ "expandingDirection", "class_qwt_plot_rescaler.html#aadeb316249fa679323252140ff241176", null ],
    [ "expandInterval", "class_qwt_plot_rescaler.html#ad3da887bf71befccf1f3094da448a502", null ],
    [ "expandScale", "class_qwt_plot_rescaler.html#ae3eb4d18dcd9ace4b7eb0bd05216c957", null ],
    [ "interval", "class_qwt_plot_rescaler.html#a52a1d762ba0add0a49c632a735d624c1", null ],
    [ "intervalHint", "class_qwt_plot_rescaler.html#a9bd02f1786d7503bd0d3e973799739ce", null ],
    [ "isEnabled", "class_qwt_plot_rescaler.html#afdafabbb963aa5b13ce4a6bae33958da", null ],
    [ "orientation", "class_qwt_plot_rescaler.html#a5afb70d8dc928dedcb7daa3f95e7d506", null ],
    [ "plot", "class_qwt_plot_rescaler.html#aca7a946dd53744e4640be383cd161a7c", null ],
    [ "plot", "class_qwt_plot_rescaler.html#ae49ce39ba8c7670bd8f70cf9078d96d5", null ],
    [ "referenceAxis", "class_qwt_plot_rescaler.html#ae495168aec756dd617a5ad0c24e0eede", null ],
    [ "rescale", "class_qwt_plot_rescaler.html#afd6783b36fa0a2f61b481bffc5f33251", null ],
    [ "rescale", "class_qwt_plot_rescaler.html#a6c609a90c617ddddb5c0e282ceeeeeac", null ],
    [ "rescalePolicy", "class_qwt_plot_rescaler.html#adceb6d094c1db33c1ef23e18e1b49185", null ],
    [ "setAspectRatio", "class_qwt_plot_rescaler.html#a31f71937b4cff3e60f74db83beb6d2de", null ],
    [ "setAspectRatio", "class_qwt_plot_rescaler.html#aa747f1cf3ecc3a37f98d0972e1db600b", null ],
    [ "setEnabled", "class_qwt_plot_rescaler.html#a6f1c886d127ec4943552170dc63edf29", null ],
    [ "setExpandingDirection", "class_qwt_plot_rescaler.html#aa2ecffbc14d951ab9f1809c14bc4e21b", null ],
    [ "setExpandingDirection", "class_qwt_plot_rescaler.html#a1681eb01b65b91e8b2583d87f890576f", null ],
    [ "setIntervalHint", "class_qwt_plot_rescaler.html#afefb0ec065ff855785d0198fc04a07d3", null ],
    [ "setReferenceAxis", "class_qwt_plot_rescaler.html#a6f13d60cc1e1071a6830ea30ccbcca37", null ],
    [ "setRescalePolicy", "class_qwt_plot_rescaler.html#ae6b7df41b5387d0aed532559546e40b6", null ],
    [ "syncScale", "class_qwt_plot_rescaler.html#a1a83473ef31ff45d1595eca80c2d3b1d", null ],
    [ "updateScales", "class_qwt_plot_rescaler.html#a999de79352fda2a89e32d1a8831fa5fd", null ]
];